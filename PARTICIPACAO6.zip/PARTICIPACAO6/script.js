const output = document.getElementById('output');
const postIdInput = document.getElementById('postId');

function getAllPosts() {
  fetch('https://jsonplaceholder.typicode.com/posts')
    .then(res => res.json())
    .then(data => output.textContent = JSON.stringify(data, null, 2))
    .catch(err => output.textContent = 'Erro: ' + err.message);
}

function getPostById() {
    const id = postIdInput.value.trim();

    if (!id || isNaN(id) || parseInt(id) <= 0) {
        output.textContent = 'Por favor, insira um ID válido.';
        return;
    }

    fetch(`https://jsonplaceholder.typicode.com/posts/${id}`)
        .then(res => {
        if (!res.ok) throw new Error('Post não encontrado');
        return res.json();
        })
        .then(data => output.textContent = JSON.stringify(data, null, 2))
        .catch(err => output.textContent = 'Erro: ' + err.message);
    }

function createPost() {
  fetch('https://jsonplaceholder.typicode.com/posts', {
    method: 'POST',
    body: JSON.stringify({
      title: 'Título do novo post',
      body: 'Este é o conteúdo do novo post.',
      userId: 1
    }),
    headers: {
      'Content-type': 'application/json; charset=UTF-8',
    },
  })
    .then(res => res.json())
    .then(data => output.textContent = JSON.stringify(data, null, 2))
    .catch(err => output.textContent = 'Erro: ' + err.message);
}

function updatePost() {
  fetch('https://jsonplaceholder.typicode.com/posts/1', {
    method: 'PUT',
    body: JSON.stringify({
      id: 1,
      title: 'Post atualizado',
      body: 'Conteúdo atualizado com sucesso.',
      userId: 1
    }),
    headers: {
      'Content-type': 'application/json; charset=UTF-8',
    },
  })
    .then(res => res.json())
    .then(data => output.textContent = JSON.stringify(data, null, 2))
    .catch(err => output.textContent = 'Erro: ' + err.message);
}

function deletePost() {
  fetch('https://jsonplaceholder.typicode.com/posts/1', {
    method: 'DELETE',
  })
    .then(() => output.textContent = 'Post deletado com sucesso (simulado pela API).')
    .catch(err => output.textContent = 'Erro: ' + err.message);
}