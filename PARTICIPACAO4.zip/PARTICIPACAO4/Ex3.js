// Crie uma função que retorne uma Promise seguindo as seguintes orientações:
// Se o argumento da função não for um número, retorne uma promessa rejeitada instantaneamente e 
// forneça uma mensagem de "erro" aos dados (em uma string);
// 
// Se os dados forem um número ímpar, retorne uma promessa resolvida 1 segundo depois e forneça os 
// dados "ímpares" (em uma string);
// 
// Se os dados forem um número par, retorne uma promessa rejeitada 2 segundos depois e forneça os dados "par" (em uma string)

function verificarNumero(num) {
    return new Promise((res, rej) => {
        if (typeof num !== 'number') {
            rej("Erro: o argumento não é um número");
        }
        if (num % 2 !== 0) {
            setTimeout(() => {
                res(`${num} é par`);
            }, 1000);
        } else {
            setTimeout(() => {
                rej(`${num} é Ímpar`);
            }, 2000);
        }
    });
}

verificarNumero(5)
    .then((resultado) => {
        console.log(resultado);
    })
    .catch((error) => {
        console.log(error);
    });