// Crie uma função que após 5 segundos dobre o resultado de um número passado como argumento.
// Essa função deverá retornar uma Promise. Use o setTimeOut como temporizador.

function dobrarEm5Segundos(x) {
 return new Promise((res, rej) => {
    setTimeout(() => {
        setTimeout(() => {
            if(typeof x === 'number')
                res(x * 2);
            else
                rej("Errado!");
        }, 5000);
    });
 });
}


dobrarEm5Segundos(5).then((resultado) => {
    console.log(resultado)
}).catch(error => {
    console.log(error);
})