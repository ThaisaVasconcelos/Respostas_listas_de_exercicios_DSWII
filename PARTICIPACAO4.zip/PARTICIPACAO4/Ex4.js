// Implemente as funções que retornam Promises seguindo a seguinte lógica:
// firstPromise: deve ser resolvido se numInt é maior que 2 e rejeitada caso contrário;
// secondPromise: deve ser resolvida se data + 1 é par e rejeitada caso contrário.


function firstPromise(numInt) {
    return new Promise((res, rej) => {
        if (numInt > 2) {
            res(valor);	
        } else {
            rej(`${numInt} é menor ou igual a 2`);
        }
    });
}

function secondPromise(data) {
    return new Promise((res, rej) => {
        if ((data + 1) % 2 === 0) {
            res(`${data} + 1 = ${data+1} que é um número par`);
        } else {
            rej(`${data} + 1 = ${data+1} que é um número ímpar`);
        }
    });
}

async function name() {
    try {
        const valor = await firstPromise(0);
        const valor2 = await secondPromise(valor); 

        console.log(valor2);
    } catch (error) {
        console.log(error);
    }
}

name();